============================================================
           EPSTEIN FILES - BATCH DOWNLOADER
============================================================

Author: Mu_rpy
Version: epstein-files-downloader-v1.0

--- QUICK START ---

1. Open a terminal (CMD or PowerShell) in this folder.
2. Run: start.bat
3. Press 1, and watch the magic 👍

--- REQUIREMENTS ---

- Electricity
- Internet

============================================================